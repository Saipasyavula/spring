INSERT INTO EMPLOYEE
VALUES (1, 'Warsaw', 'Plac Zbawiciela', 'Tumilowicz');

INSERT INTO EMPLOYEE
VALUES (2, 'Krakow', 'Plac Szczepanski', 'Mrozek');

INSERT INTO EMPLOYEE
VALUES (3, 'Krakow', null, 'Lem');

INSERT INTO EMPLOYEE
VALUES (4, 'Key West', '907 Whitehead St', 'Hemingway');

INSERT INTO ISSUE
VALUES (1, 'stay sharp!', 1);

INSERT INTO ISSUE
VALUES (2, 'improve coding skills', 1);

INSERT INTO ISSUE
VALUES (3, 'prepare newest novel for editing', 2);

COMMIT;